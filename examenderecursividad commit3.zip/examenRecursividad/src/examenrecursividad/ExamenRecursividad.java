package examenrecursividad;

import java.util.Scanner;

public class ExamenRecursividad {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); //Para enteros
        Scanner scannerTxt = new Scanner(System.in); //Para textos
        int ejercicio = 0;

        System.out.println("Ejercicios:");
        System.out.println("1: Demuestre que es posible crear una función recursiva que permita sumar todos los valores un arreglo \n"
                + "desde su último índice hasta el primero, retornando al final ese resultado de la suma.");
        System.out.println("");
        System.out.println("2: Con un TAD lista circular precargado con nodos que contengan como valor almacenado una palabra , \n"
                + "desarrolle una función que permita concatenar todos los valores y agregar un espacio de por medio(\" \"), \n"
                + "retornando esa cadena de texto resultante al final de la operación.");
        System.out.println("");
        System.out.println("3: Realice una función recursiva que imprima los valores invertidos de un TAD Pila, no es necesario \n"
                + "conservar los valores de la misma una vez realizada está función.");
        System.out.println("");
        System.out.println("4: Cree una función permita realizar la multiplicación de 2 valores A y B, dónde A sea un factorial \n"
                + "de un número cualquiera y B sea la potencia de un número cualquiera elevado a cualquier otro número, por ejemplo: 8! + 4⁷.");
        System.out.println("");
        
        while(ejercicio > 4 || ejercicio < 1){
            System.out.print("Elija el numero del ejercicio -> ");
            ejercicio = scanner.nextInt();
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
            switch(ejercicio){
                case 1:
                    System.out.println("1: Demuestre que es posible crear una función recursiva que permita sumar todos los valores un arreglo \n"
                            + "desde su último índice hasta el primero, retornando al final ese resultado de la suma.");
                    System.out.print("Ingrese el tamaño del arreglo -> ");
                    int tamanoArreglo = scanner.nextInt();
                    System.out.println("");
                    Integer[] arregloEjercicio1 = new Integer[tamanoArreglo];
                    
                    for (int i = 0; i < tamanoArreglo; i++) {
                        System.out.print("Ingrese el elemento nro " + (i+1) + " del arreglo -> ");
                        arregloEjercicio1[i] = scanner.nextInt();
                    }
                    System.out.println("");
                    System.out.println(ejercicio1(arregloEjercicio1, arregloEjercicio1.length));
                    break;
                
                case 2:
                    System.out.println("2: Con un TAD lista circular precargado con nodos que contengan como valor almacenado una palabra , \n"
                            + "desarrolle una función que permita concatenar todos los valores y agregar un espacio de por medio(\" \"), \n"
                            + "retornando esa cadena de texto resultante al final de la operación.");
                    
                    listaCircular listaEjercicio2 = new listaCircular();
                    listaEjercicio2.push(new nodo("Esta"));
                    listaEjercicio2.push(new nodo("es"));
                    listaEjercicio2.push(new nodo("una"));
                    listaEjercicio2.push(new nodo("cadena"));
                    listaEjercicio2.push(new nodo("de"));
                    listaEjercicio2.push(new nodo("caracteres"));
                    listaEjercicio2.push(new nodo("concatenada"));
                    listaEjercicio2.push(new nodo("recursivamente."));
                    
                    System.out.println(ejercicio2(listaEjercicio2, listaEjercicio2.primero));
                    break;
                
                case 3:
                    System.out.println("3: Realice una función recursiva que imprima los valores invertidos de un TAD Pila, no es necesario \n"
                            + "conservar los valores de la misma una vez realizada está función.");
                    System.out.print("Cuantos datos desea añadir a la pila? -> ");
                    int tamanoPila = scanner.nextInt();
                    System.out.println("");
                    
                    pila pilaEjercicio3 = new pila();
                    
                    for (int i = 0; i < tamanoPila; i++) {
                        System.out.print("Ingrese el elemento nro " + (i+1) + " de la pila -> ");
                        pilaEjercicio3.apilar(new nodo(scannerTxt.nextLine()));
                    }
                    System.out.println("");

                    ejercicio3(pilaEjercicio3);
                    break;
                
                case 4:
                    System.out.println("4");
                    break;
                
                default:
                    System.out.println("Ingrese un numero de ejercicio correcto");
                    break;
            }
        }
    }
    
    public static int ejercicio1(Integer[] arreglo, int tamanoArreglo){        
        if(tamanoArreglo == 1){
            System.out.print(arreglo[0] + " = ");
            return arreglo[0];
        }
        else{
            System.out.print(arreglo[tamanoArreglo - 1] + " + ");
            return arreglo[tamanoArreglo - 1] + ejercicio1(arreglo, tamanoArreglo - 1);
        }
    }
    
    public static String ejercicio2(listaCircular lista, nodo nodoActual){
        if(nodoActual.siguiente == lista.primero){
            return nodoActual.valor;
        }else{
            String frase = nodoActual.valor;
            nodoActual = nodoActual.siguiente;
            return frase + " " + ejercicio2(lista, nodoActual);
        }
    }
    
    public static void ejercicio3(pila pila){
        if (pila.tope.siguiente == null) {
            System.out.println(pila.desapilar().valor);
        }else{
            System.out.print(pila.desapilar().valor + " -> ");
            ejercicio3(pila);
        }
    }
    
    
    
    
    public static class nodo{
        String valor;
        nodo siguiente;
        
        public nodo(String valor){
            this.valor = valor;
        }
    }
    public static class listaCircular{
        nodo primero;
        nodo ultimo;
        
        public listaCircular(){
            this.primero = null;
            this.ultimo = null;
        }
        
        public boolean vacio(){
            return this.primero == null;
        }
        
        public void push(nodo nuevoNodo){
            if (this.vacio()) {
                this.primero = nuevoNodo;
                this.ultimo = nuevoNodo;
                nuevoNodo.siguiente = this.primero;
            }else{
                this.ultimo.siguiente = nuevoNodo;
                nuevoNodo.siguiente = this.primero;
                this.ultimo = nuevoNodo;
            }
        }
    }
    public static class pila{
        nodo tope;
        
        public pila(){
            this.tope = null;
        }
        
        public boolean vacio(){
            return this.tope == null;
        }
        
        public void apilar(nodo nuevoNodo){
            if (this.vacio()) {
                this.tope = nuevoNodo;
            }else{
                nuevoNodo.siguiente = this.tope;
                this.tope = nuevoNodo;
            }
        }
        public nodo desapilar(){
            if (this.vacio()) {
                return null;
            }else{
            nodo primero = this.tope;
            this.tope = this.tope.siguiente;
            return primero;
            }
        }
}
}
