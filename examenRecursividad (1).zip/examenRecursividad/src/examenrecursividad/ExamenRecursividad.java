package examenrecursividad;

import java.util.Scanner;

public class ExamenRecursividad {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int ejercicio = 0;

        System.out.println("Ejercicios:");
        System.out.println("1: Demuestre que es posible crear una función recursiva que permita sumar todos los valores un arreglo \n"
                + "desde su último índice hasta el primero, retornando al final ese resultado de la suma.");
        System.out.println("");
        System.out.println("2: Con un TAD lista circular precargado con nodos que contengan como valor almacenado una palabra , \n"
                + "desarrolle una función que permita concatenar todos los valores y agregar un espacio de por medio(\" \"), \n"
                + "retornando esa cadena de texto resultante al final de la operación.");
        System.out.println("");
        System.out.println("3: Realice una función recursiva que imprima los valores invertidos de un TAD Pila, no es necesario \n"
                + "conservar los valores de la misma una vez realizada está función.");
        System.out.println("");
        System.out.println("4: Cree una función permita realizar la multiplicación de 2 valores A y B, dónde A sea un factorial \n"
                + "de un número cualquiera y B sea la potencia de un número cualquiera elevado a cualquier otro número, por ejemplo: 8! + 4⁷.");
        System.out.println("");
        
        while(ejercicio > 4 || ejercicio < 1){
            System.out.print("Elija el numero del ejercicio -> ");
            ejercicio = scanner.nextInt();
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
            switch(ejercicio){
                case 1:
                    System.out.println("1: Demuestre que es posible crear una función recursiva que permita sumar todos los valores un arreglo \n"
                            + "desde su último índice hasta el primero, retornando al final ese resultado de la suma.");
                    System.out.print("Ingrese el tamaño del arreglo -> ");
                    int tamanoArreglo = scanner.nextInt();
                    System.out.println("");
                    Integer[] arregloEjercicio1 = new Integer[tamanoArreglo];
                    
                    for (int i = 0; i < tamanoArreglo; i++) {
                        System.out.print("Ingrese el elemento nro " + (i+1) + " del arreglo -> ");
                        arregloEjercicio1[i] = scanner.nextInt();
                    }
                    System.out.println("");
                    System.out.println(ejercicio1(arregloEjercicio1, arregloEjercicio1.length));
                    break;
                
                case 2:
                    System.out.println("2: Con un TAD lista circular precargado con nodos que contengan como valor almacenado una palabra , \n"
                            + "desarrolle una función que permita concatenar todos los valores y agregar un espacio de por medio(\" \"), \n"
                            + "retornando esa cadena de texto resultante al final de la operación.");
                    
                    listaCircular lista = new listaCircular();
                    lista.push(new nodo("Esta"));
                    lista.push(new nodo("es"));
                    lista.push(new nodo("una"));
                    lista.push(new nodo("cadena"));
                    lista.push(new nodo("de"));
                    lista.push(new nodo("caracteres"));
                    lista.push(new nodo("concatenada"));
                    lista.push(new nodo("recursivamente."));
                    
                    System.out.println(ejercicio2(lista, lista.primero));
                    break;
                
                case 3:
                    System.out.println("3");
                    break;
                
                case 4:
                    System.out.println("4");
                    break;
                
                default:
                    System.out.println("Ingrese un numero de ejercicio correcto");
                    break;
            }
        }
    }
    
    public static int ejercicio1(Integer[] arreglo, int tamanoArreglo){        
        if(tamanoArreglo == 1){
            System.out.print(arreglo[0] + " = ");
            return arreglo[0];
        }
        else{
            System.out.print(arreglo[tamanoArreglo - 1] + " + ");
            return arreglo[tamanoArreglo - 1] + ejercicio1(arreglo, tamanoArreglo - 1);
        }
    }
    
    public static String ejercicio2(listaCircular lista, nodo nodoActual){
        if(nodoActual.siguiente == lista.primero){
            return nodoActual.valor;
        }else{
            String frase = nodoActual.valor;
            nodoActual = nodoActual.siguiente;
            return frase + " " + ejercicio2(lista, nodoActual);
        }
    }
    
    
    
    
    public static class nodo{
        String valor;
        nodo siguiente;
        
        public nodo(String valor){
            this.valor = valor;
        }
    }
    public static class listaCircular{
        nodo primero;
        nodo ultimo;
        
        public listaCircular(){
            this.primero = null;
            this.ultimo = null;
        }
        
        public boolean vacio(){
            return this.primero == null;
        }
        
        public void push(nodo nuevoNodo){
            if (this.vacio()) {
                this.primero = nuevoNodo;
                this.ultimo = nuevoNodo;
                nuevoNodo.siguiente = this.primero;
            }else{
                this.ultimo.siguiente = nuevoNodo;
                nuevoNodo.siguiente = this.primero;
                this.ultimo = nuevoNodo;
            }
        }
    }
}
